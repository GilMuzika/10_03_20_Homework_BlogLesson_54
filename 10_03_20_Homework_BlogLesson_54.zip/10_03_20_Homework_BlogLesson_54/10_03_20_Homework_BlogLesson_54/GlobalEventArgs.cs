﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10_03_20_Homework_BlogLesson_54
{
    class GlobalEventArgs
    {
        public bool IsSmoke { get; set; }
        public string Smoker { get; set; }
        public string Name { get; set; }
        public string Age { get; set; }
        public string Height { get; set; }
    }
}
